/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.palindrome.check;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author samiulsaki
 */
@WebService(serviceName = "PalindromeCheck")
public class PalindromeCheck {
    /**
     * Palindrome web service operation
     * @param txt
     * @return 
     */
    @WebMethod(operationName = "checkPalindrome")
    public boolean isPalindrome(@WebParam(name = "string") String txt) {
        // The String forward will be created by converting string to 
        // lowercase and replacing everything except numbers and alphabets        
        String forward = txt.toLowerCase().replaceAll("\\W", ""); 
        if (forward == null) 
            return true;
        int len  = forward.length();
        for (int i=0; i<len/2 ; i++){
            if (forward.charAt(i) != forward.charAt(len - i - 1)){
                return false;
            }
        }       
        return true;     
    }
}
