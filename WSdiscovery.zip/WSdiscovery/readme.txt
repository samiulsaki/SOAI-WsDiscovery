wsdiscovery-gui2-... - standalone GUI for publishing/probing/unpublishing
wsdiscovery-lib-...  - library for use in Java programs
WsDiscoveryGui.java  - source code for GUI - can be studied as an additional example (see lecture foils also)

(Checked out from repository 2013-10-28, version 131)
