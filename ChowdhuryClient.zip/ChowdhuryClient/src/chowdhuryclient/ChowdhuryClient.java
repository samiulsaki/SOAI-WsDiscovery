/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chowdhuryclient;

import java.net.MalformedURLException;
import javax.xml.namespace.QName;
import com.ms.wsdiscovery.WsDiscoveryFinder;
import com.ms.wsdiscovery.exception.WsDiscoveryException;
import com.ms.wsdiscovery.exception.WsDiscoveryNetworkException;
import com.ms.wsdiscovery.servicedirectory.WsDiscoveryService;
import com.ms.wsdiscovery.servicedirectory.interfaces.IWsDiscoveryServiceCollection;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author samiulsaki
 */
public class ChowdhuryClient {

    public static void main(String[] args) throws WsDiscoveryException, InterruptedException, WsDiscoveryNetworkException, MalformedURLException {
        int x = 0;
        do {
        // Create new finder instance. 
        System.out.println("Creating new finder-instance...");
        // Create finder instance
        WsDiscoveryFinder discovery = new WsDiscoveryFinder();
        // Search for a specific service
        int timeout = 5000; // milliseconds
        QName portType = new QName("http://check.palindrome.com/", "PalindromeCheck");
        // Search for with 5 seconds timeout...
        System.out.println("Searching for service with port type \"" + portType.toString() + "\"");        
        IWsDiscoveryServiceCollection result = (IWsDiscoveryServiceCollection) discovery.find(portType, timeout);
        System.out.println("Available services (if any):");        
        if (result.isEmpty()) {
            System.out.println("No services found.");
            discovery.done();
        } else {
            // Display the results.
            System.out.println("** Discovered service: **");
            WsDiscoveryService service = (WsDiscoveryService) result.toArray()[0];
            JOptionPane.showMessageDialog(null, service.toString(), "This Service is found", 1);
            System.out.println("---");
            URL wsdl = new URL(service.getXAddrs().get(0));
            submitForm(wsdl);
            System.out.println("Service says: " + wsdl);
            // clean up
            discovery.done();
            x=1;
        }
        } while (x==0);
    }

    private static void submitForm(URL wsdl) {

        JFrame UserInterface = new JFrame();
        UserInterface.setTitle("Palindrome Service");
        //set the popup screen to center automatically
        UserInterface.setSize(300,250);
        //This will center the JFrame in the middle of the screen
        UserInterface.setLocationRelativeTo(null);
        UserInterface.setVisible(true);
        UserInterface.setResizable(false);
        JPanel Panel = new JPanel();
        JButton clear = (JButton) Panel.add(new JButton("Clear"));
        Panel.add(new JLabel("<html>Check the Palindrome<br> <br> <br> <br>Enter string here<br> <br> <br> <br> <br></html>", SwingConstants.CENTER));
        JTextField input_string = (JTextField) Panel.add(new JTextField(15));
        input_string.setToolTipText("Please enter some text here and press return");
        input_string.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                String userInput = input_string.getText();
                System.out.println("Response: " + checkPalindrome(userInput, wsdl));
            }
        });
        clear.addActionListener((ActionEvent e) -> {
            input_string.setText("");
            //input_string.setText(null); //or use this
        });

        Panel.setPreferredSize(new Dimension(400, 200));
        //size for frame
        Panel.setBackground(Color.yellow);
        JButton close = (JButton) Panel.add(new JButton("Exit Application"));
        close.addActionListener(e -> System.exit(0));
        UserInterface.add(Panel);
        UserInterface.pack();
        UserInterface.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        UserInterface.setVisible(true);
    }

    private static boolean checkPalindrome(java.lang.String string, URL wsdlLocation) {
        
        com.palindrome.check.PalindromeCheck_Service service = new com.palindrome.check.PalindromeCheck_Service(wsdlLocation);
        com.palindrome.check.PalindromeCheck port = service.getPalindromeCheckPort();
        if (string.trim().length() > 0) {
            JOptionPane.showMessageDialog(null, string, "Following string is entered: ", 3);
            String result = "Is This String a Palindrome? " + port.checkPalindrome(string);
            JOptionPane.showMessageDialog(null, result, "Message Recieved From Service", 1);
        } else {
            JOptionPane.showMessageDialog(null, "A Null string is sent to palindrome web service", "The string is empty", 2);
            String result = "Is Null String a Palindrome? " + port.checkPalindrome(string);
            JOptionPane.showMessageDialog(null, result, "Message Recieved From Service", 1);
        }
        return port.checkPalindrome(string);
    }

}
