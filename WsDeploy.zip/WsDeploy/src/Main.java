
import com.ms.wsdiscovery.WsDiscoveryConstants;
import com.ms.wsdiscovery.WsDiscoveryFactory;
import com.ms.wsdiscovery.WsDiscoveryServer;
import com.ms.wsdiscovery.exception.WsDiscoveryException;
import com.ms.wsdiscovery.servicedirectory.WsDiscoveryService;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.*;
import java.util.Scanner;
import javax.xml.namespace.QName;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IEUser
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws com.ms.wsdiscovery.exception.WsDiscoveryException
     * @throws java.lang.InterruptedException
     * @throws java.net.MalformedURLException
     * @throws java.net.UnknownHostException
     * @throws java.net.SocketException
     */
    public static void main(String[] args) throws WsDiscoveryException, InterruptedException, MalformedURLException, UnknownHostException, SocketException {
        // Please enter your own ip address
        String ip = "10.0.0.108"; 
        InetAddress addr = InetAddress.getByName(ip);
        NetworkInterface nif = NetworkInterface.getByInetAddress(addr);
        WsDiscoveryConstants.multicastInterface = nif;
        WsDiscoveryServer wsd = new WsDiscoveryServer();
        wsd.start();
        wsd.publish(new com.palindrome.check.PalindromeCheck_Service());
        
        //WsDiscoveryService service = WsDiscoveryFactory.createService( 
        //        new QName("http://check.palindrome.com/","PalindromeCheck"), // portType
        //        "http://check.palindrome.com/", // scope
        //        "http://10.0.0.108:8080/ChowdhuryService/PalindromeCheck?wsdl"); // endpoint
        //wsd.publish(service);
        
        
        // just wait till user aborts
        System.out.println("Press <enter> to continue");
        Scanner scanIn = new Scanner(System.in);
        String tmp = scanIn.nextLine();
        scanIn.close();
        // done will issue BYE messages
        wsd.done();
    }
}
