
import com.ms.wsdiscovery.WsDiscoveryConstants;
import com.ms.wsdiscovery.WsDiscoveryFactory;
import com.ms.wsdiscovery.WsDiscoveryServer;
import com.ms.wsdiscovery.exception.WsDiscoveryException;
import com.ms.wsdiscovery.servicedirectory.WsDiscoveryService;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.xml.namespace.QName;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author samiulsaki
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws com.ms.wsdiscovery.exception.WsDiscoveryException
     * @throws java.lang.InterruptedException
     * @throws java.net.MalformedURLException
     * @throws java.net.UnknownHostException
     * @throws java.net.SocketException
     */
    public static void main(String[] args) throws InterruptedException, MalformedURLException {
        // Please enter your own ip address
        JFrame guiFrame = new JFrame();
        //make sure the program exits when the frame closes
        guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        guiFrame.setTitle("User IP Address");
        guiFrame.setSize(300,250);
        //This will center the JFrame in the middle of the screen
        guiFrame.setLocationRelativeTo(null);         
        JPanel Panel = new JPanel();
        JButton clear = (JButton) Panel.add(new JButton("Clear"));
        JTextField input_string = (JTextField) Panel.add(new JTextField(16));
        input_string.setToolTipText("Please enter your ip address here and press return");
        JButton close = (JButton) Panel.add(new JButton("Exit"));
        close.addActionListener(e -> System.exit(0));
        //String ip = "10.0.0.108"; 
        input_string.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                String ip = input_string.getText();                
                System.out.println("IP : " + ip);
                try {
                    publish_service(ip);
                } catch (UnknownHostException | SocketException | WsDiscoveryException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        guiFrame.add(Panel);
        guiFrame.pack();
        guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        guiFrame.setVisible(true);
    }
    public static void publish_service(String ip) throws UnknownHostException, SocketException, WsDiscoveryException {
        if (ip.trim().length() > 0) {
            JOptionPane.showMessageDialog(null, "Minimise the window for now. You can close the service by pressing enter on console", "Service is Running", 3);
            InetAddress addr = InetAddress.getByName(ip);
            NetworkInterface nif = NetworkInterface.getByInetAddress(addr);
            WsDiscoveryConstants.multicastInterface = nif;
            WsDiscoveryServer wsd = new WsDiscoveryServer();
            wsd.start();
            wsd.publish(new com.palindrome.check.PalindromeCheck_Service());

            // just wait till user aborts
            System.out.println("Press <enter> to continue");
            Scanner scanIn = new Scanner(System.in);
            String tmp = scanIn.nextLine();
            scanIn.close();
            // done will issue BYE messages
            wsd.done();
        } else {
            JOptionPane.showMessageDialog(null, "Please insert an IP address", "No IP Inserted ", 3);
            System.out.println("----");
        }
    }
}

